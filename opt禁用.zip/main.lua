API_VERSION = 3

function start_services()
    os.execute("start gameopt_hal_service-1-0")
    os.execute("start vendor.urcc-hal-aidl")
    os.execute("start oiface")
end

function stop_services()
    os.execute("stop gameopt_hal_service-1-0")
    os.execute("stop vendor.urcc-hal-aidl")
    os.execute("stop oiface")
end

function load_fas(pid, pkg)
    stop_services()
end

function unload_fas(pid, pkg)
    start_services()
end